Cow Clicker v1.2 By TIny_Hacker

REQUIREMENTS

Doors CS 7.2 (dcs.cemetech.net)
A TI-83 Plus, TI-83 Plus Silver Edition, TI-84 Plus, or TI-84 Plus Silver Edition

HOW TO INSTALL

1. Dowload Cow Clicker from ticalc.org (If you are reading this document, you probably already have downloaded it, though)

2. Extract CowClicker.zip with an archive extractor.

3. Dowload and install TiLP (https://www.ticalc.org/archives/files/fileinfo/374/37481.html) or TI Connect CE (https://education.ti.com/en/products/computer-software/ti-connect-ce-sw)

4. Use TiLP or TI Connect CE to send COW.8xp to your calculator.

GAMEPLAY

Use the cursor to click on cows. You may click one cow an hour. Clicking a cow gives you Mooney and Clicks, which can be used in the in-game shop to buy upgrades, more cows, and items. Be sure to share your score in the Cow Clicker thread at cemete.ch/forum/viewtopic.php?t=16884

CONTROLS

Arrow keys are used to move the cursor, and [2ND] or [ENTER] to click on a cow or button.

Thanks for playing Cow Clicker!
