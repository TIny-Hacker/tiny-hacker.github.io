 ________  ________  ________           _________      ________  ___       ________  ________  ___  ___
|\   ___ \|\   ____\|\   ____\         |\_____   \    |\   ____\|\  \     |\   __  \|\   ____\|\  \|\  \
\ \  \_|\ \ \  \___|\ \  \___|_        \|____/  /|    \ \  \___|\ \  \    \ \  \|\  \ \  \___|\ \  \/  /_
 \ \  \\ \ \ \  \    \ \_____  \            /  / /     \ \  \    \ \  \    \ \  \ \  \ \  \    \ \   __  \
  \ \  \\_\ \ \  \____\|_____\  \          /  / /       \ \  \____\ \  \____\ \  \_\  \ \  \____\ \  \ \  \
   \ \_______\ \_______\|\_______\        /__/ /         \ \_______\ \_______\ \_______\ \_______\ \__\ \__\
    \|_______|\|_______|\|_______|        |__|/           \|_______|\|_______|\|_______|\|_______|\|__|\|__|

=======By TIny_Hacker

Overview:
Thanks for downloading DCS 7 Clock v1.1!
DCS 7 Clock is a digital clock that displays the current hour in twelve-hour time whenever ran from Doors CS.
To run Clock, make sure it is in the RAM, and then run it in Doors CS. You should see the previous icon become
the current hour, as well as whether it is Morning or Afternoon. Just remember to have the clock on your calculator
(accessible through [MODE]->Set Clock) is set correctly!

Installation:
Download dcs_clock.zip from either www.cemetech.net or www.ticalc.org. (You've probably already done that if you're 
reading this, however) Open the zip file with an unarchiving program, and then send it to your calculator using
TiLP or TI Connect. Then you can run the program through DCS whenever you want.

Credits:
TIny_Hacker, who wrote the program
BioHazard, who fixed my stupid bug and suggested ideas
Kerm Martian, for SourceCoder3 (www.cemetech.net/sc) which I used to make the icons needed for the program
LogicalJoe, for optimization to reduce the program to < 500 bytes